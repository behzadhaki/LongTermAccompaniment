
        # MIDI Collection

        ## Summary
        This collection contains 16214 MIDI files.

        This subset has no genre tags, but all files have 4/4 time signature.    

        ## Performed MIDI files
        Performed Files: 16214
        Mechanical Files: 0

        ## Genre Distribution
        {('Disco',): 1814, ('Reggae',): 1600, ('Pop',): 1600, ('Jazz',): 1600, ('Blues',): 1600, ('Funk',): 1600, ('Latin',): 1600, ('Afro',): 1600, ('Hip-Hop/R&B/Soul',): 1600, ('Rock',): 1600}

        ## Meter Distribution
        {'[4_4]': 16214}

        ## Tempo Distribution
        {'min': 50.0, 'max': 290.0, 'mean': 115.50125447144445, 'median': 120.0, 'std_dev': 27.659088240301596}

        