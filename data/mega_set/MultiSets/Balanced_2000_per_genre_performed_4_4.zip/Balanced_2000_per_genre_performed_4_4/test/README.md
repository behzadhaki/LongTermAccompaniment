
        # MIDI Collection

        ## Summary
        This collection contains 2026 MIDI files.

        This subset has no genre tags, but all files have 4/4 time signature.    

        ## Performed MIDI files
        Performed Files: 2026
        Mechanical Files: 0

        ## Genre Distribution
        {('Disco',): 226, ('Reggae',): 200, ('Pop',): 200, ('Jazz',): 200, ('Blues',): 200, ('Funk',): 200, ('Latin',): 200, ('Afro',): 200, ('Hip-Hop/R&B/Soul',): 200, ('Rock',): 200}

        ## Meter Distribution
        {'[4_4]': 2026}

        ## Tempo Distribution
        {'min': 50.0, 'max': 290.0, 'mean': 115.53999012833168, 'median': 120.0, 'std_dev': 27.680768699131573}

        