
        # MIDI Collection

        ## Summary
        This collection contains 32000 MIDI files.

        This subset has no genre tags, but all files have 4/4 time signature.    

        ## Performed MIDI files
        Performed Files: 32000
        Mechanical Files: 0

        ## Genre Distribution
        {('Reggae',): 3200, ('Pop',): 3200, ('Jazz',): 3200, ('Blues',): 3200, ('Funk',): 3200, ('Latin',): 3200, ('Disco',): 3200, ('Afro',): 3200, ('Hip-Hop/R&B/Soul',): 3200, ('Rock',): 3200}

        ## Meter Distribution
        {'[4_4]': 32000}

        ## Tempo Distribution
        {'min': 50.0, 'max': 290.0, 'mean': 115.46782478938046, 'median': 120.0, 'std_dev': 25.821274656370875}

        