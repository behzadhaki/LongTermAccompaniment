
        # MIDI Collection

        ## Summary
        This collection contains 4000 MIDI files.

        This subset has no genre tags, but all files have 4/4 time signature.    

        ## Performed MIDI files
        Performed Files: 4000
        Mechanical Files: 0

        ## Genre Distribution
        {('Reggae',): 400, ('Pop',): 400, ('Jazz',): 400, ('Blues',): 400, ('Funk',): 400, ('Latin',): 400, ('Disco',): 400, ('Afro',): 400, ('Hip-Hop/R&B/Soul',): 400, ('Rock',): 400}

        ## Meter Distribution
        {'[4_4]': 4000}

        ## Tempo Distribution
        {'min': 60.0, 'max': 290.0, 'mean': 115.37489414694896, 'median': 120.0, 'std_dev': 25.707241098844246}

        