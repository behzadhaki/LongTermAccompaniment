
        # MIDI Collection

        ## Summary
        This collection contains 5000 MIDI files.

        This subset has no genre tags, but all files have 4/4 time signature.    

        ## Performed MIDI files
        Performed Files: 5000
        Mechanical Files: 0

        ## Genre Distribution
        {('Reggae',): 500, ('Pop',): 500, ('Jazz',): 500, ('Blues',): 500, ('Funk',): 500, ('Latin',): 500, ('Disco',): 500, ('Afro',): 500, ('Hip-Hop/R&B/Soul',): 500, ('Rock',): 500}

        ## Meter Distribution
        {'[4_4]': 5000}

        ## Tempo Distribution
        {'min': 50.0, 'max': 290.0, 'mean': 114.74714854639586, 'median': 120.0, 'std_dev': 24.851152298494544}

        