
        # MIDI Collection

        ## Summary
        This collection contains 40000 MIDI files.

        This subset has no genre tags, but all files have 4/4 time signature.    

        ## Performed MIDI files
        Performed Files: 40000
        Mechanical Files: 0

        ## Genre Distribution
        {('Reggae',): 4000, ('Pop',): 4000, ('Jazz',): 4000, ('Blues',): 4000, ('Funk',): 4000, ('Latin',): 4000, ('Disco',): 4000, ('Afro',): 4000, ('Hip-Hop/R&B/Soul',): 4000, ('Rock',): 4000}

        ## Meter Distribution
        {'[4_4]': 40000}

        ## Tempo Distribution
        {'min': 50.0, 'max': 290.0, 'mean': 115.616224286992, 'median': 120.0, 'std_dev': 25.557396351005288}

        